# 0.0.1 (2014-02-18)

## Features
### tracker

* add ecommerce tracking (5dac41c)

* added setDomainName (ce2889f)



## Bug fixes
### main

* use $window._gaq (a630757)


# 0.0.1 (2014-02-18)

## Features
### tracker

* add ecommerce tracking (5dac41c)

* added setDomainName (ce2889f)



## Bug fixes
### main

* use $window._gaq (a630757)


